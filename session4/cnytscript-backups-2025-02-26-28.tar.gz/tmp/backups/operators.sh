#!/bin/bash

NUM1=5
NUM2=10
RESULT=$((NUM1 + NUM2))

echo "Sum: $RESULT"
