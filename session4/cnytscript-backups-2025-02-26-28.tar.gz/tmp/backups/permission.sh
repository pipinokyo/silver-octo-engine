#!/bin/bash


USER_DIR=$1

chmod +x $USER_DIR/*.sh
