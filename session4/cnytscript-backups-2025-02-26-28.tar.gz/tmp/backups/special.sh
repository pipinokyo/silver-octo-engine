#!/bin/bash

ls /nonexistent_directory
echo "The exit status of the last command is: $?"

